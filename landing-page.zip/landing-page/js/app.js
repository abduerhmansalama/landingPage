const sections = document.querySelectorAll("section");
const list = document.querySelectorAll("li");
let alink ; 
let lielement;
let ulelement;
function addingSections(){
ulelement= document.getElementById("navbar__list");
sections.forEach( element=>{
     lielement = document.createElement("li");
     alink = document.createElement("a");
    alink.textContent=element.getAttribute("data-nav");
    alink.setAttribute("id",element.getAttribute("data-nav"));
    alink.href="s"
    lielement.appendChild(alink);
    ulelement.appendChild(lielement);
    alink.setAttribute("onclick","scrolling()");
    alink.href='#${element.getAttribute("data-nav")';
})
}

function scrolling(){
    sections[0].scrollIntoView();

}


addingSections();
const links = document.querySelectorAll("a");
function activeSection(){
    sections.forEach( element=>{
      const bound = element.getBoundingClientRect();
      if(bound.top>0 && bound.top <150){
          
          sections.forEach(element=>{
          element.classList.remove("your-active-class");
          });
          element.classList.add("your-active-class");
          
          links.forEach(el =>{
          if((el.textContent == element.getAttribute("data-nav"))){
            el.classList.add("your-active-class");
          }
          else {
            el.classList.remove("your-active-class");
          }
        })
      }
    })
}
window.addEventListener("scroll",activeSection);
