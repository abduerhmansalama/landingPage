i have four sections 
four links 
nave bar responsive 
 in java script i creat that links add it to  lists 
with adding section functions 
we have other function to  show section active 
other to deal with action click on linke to go to specific section acording to link 
by using 
scrollIntoView function 
